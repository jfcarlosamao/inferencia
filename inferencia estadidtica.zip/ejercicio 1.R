#EJERCICO 1
#La ganancia X, de corriente, en ciertos transistores se mide en unidades iguales al logaritmo de la relaci�n de la corriente de salida con la de entrada (I0 /Ii = X). Si este logaritmo, Y, es normalmente distribuido con par�metros � = 2 y s^2 = 0.01.
#determinar:
#a. P(X>6.1)
#b. P(6.1<X<8.2)
#c. Obtener la raz�n de las corrientes de salida y entrada para una probabilidad de: P(X <x) = 0.9

#Sea la variable aleatoria discreta X, el valor de la raz�n de las corrientes de salida y entrada

#Dicha variable aleatoria, sigue una distribuci�n Lognormal, X ~ Ln(2, 0.01)

#solucion
#a
plnorm(6.1, meanlog = 2, sdlog = sqrt(0.01), lower.tail = F)
#Por lo tanto, la probabilidad de que la raz�n de las corrientes de salida y entrada sea de 6.1 es: 0.9723882, es bastante alta.

#b
plnorm(8.2, meanlog = 2, sdlog = sqrt(0.01), lower.tail = T) - plnorm(6.1, meanlog = 2, sdlog = sqrt(0.01), lower.tail = T)
#Por lo tanto, la probabilidad de que de que la raz�n de las corrientes de salida y entrada est� comprendida entre los valores 6.1 y 8.2 es: 0.8235296.

#c
qlnorm(0.9, meanlog = 2, sdlog = sqrt(0.01), lower.tail = T)
#Por lo tanto, para una probabilidad de 0.9, el el valor de la relaci�n entrada y salida de las corrientes es: 8.399357.







